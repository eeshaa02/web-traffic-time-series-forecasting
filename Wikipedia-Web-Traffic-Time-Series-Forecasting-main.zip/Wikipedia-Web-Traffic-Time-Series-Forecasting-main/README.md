# Wikipedia-Web-Traffic-Time-Series-Forecasting

This is a time series problem where the web traffic for several Wikipedia pages are forecasted using Long short-term memory (LSTM) Neural Network.

The dataset used for the problem - https://www.kaggle.com/c/web-traffic-time-series-forecasting

The model has been deployed in Heroku using Flask framework. The link for the app - https://wiki-web-traffic-forecasting.herokuapp.com/
